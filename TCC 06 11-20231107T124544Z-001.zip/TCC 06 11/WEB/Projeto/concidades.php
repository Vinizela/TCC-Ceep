<?php
session_start();
include_once "./conexao.php";

$pdo = conectar();
//traz dados
$sql = "SELECT * FROM tb_cidades";
$stmc = $pdo -> prepare($sql);
$stmc -> execute();
//buscando todas as linhas da tabela
$resuldato = $stmc ->fetchAll(PDO::FETCH_ASSOC);

//buscando um unico registro
//$resuldato = $stmc ->fetch(PDO::FETCH_ASSOC);
?> 

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/cabecalho_site.css">
    <link rel="stylesheet" href="../css/footer.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.js"></script>
    <script src="js/jquery.js"></script>
</head>
<body>
    <main>
        <table class="table table-striped table-bordered">
            <tr>
                <!-- titulos -->
                <th>codcidade</th>
                <th>nomecidade</th>
                <th>estado</th>
            </tr>

                <?php foreach ($resuldato as $cidade) { ?>
                    <tr>
                        <!-- coluna com informacao -->
                        <td> <?php echo $cidade['codcidade']; ?> </td>
                        <td> <?php echo $cidade['nomecidade']; ?> </td>
                        <td> <?php echo $cidade['estado']; ?> </td>
                        <td><a href="altcidades.php?cod=<?php echo $cidade['codcidade']?>" class="btn btn-danger">alterar</a> <a href="exccidades.php?cod=<?php echo $cidade['codcidade']?>" class="btn btn-danger">excluir</a></td>
                <?php } ?>
        </table>
    </main>

</body>
</html>