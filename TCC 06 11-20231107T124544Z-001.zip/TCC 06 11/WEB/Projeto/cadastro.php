<?php
session_start();
include "conexao.php";
include_once("funcaoData.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $datanascimento = brmy($_POST['datanascimento']); // Não é necessário o uso de parênteses aqui
    $cpf = $_POST['cpf'];
    $numero = $_POST['numero'];
    $senha = md5($_POST['senha']);
    $codcidade = '';

    $sql = "INSERT INTO tb_clientes (nome, email, datanascimento, cpf, numero, senha, codcidade) 
            VALUES (:na, :e, :da, :cp, :nu, :s, :ci)";

    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':na', $nome);
    $stmt->bindParam(':e', $email);
    $stmt->bindParam(':da', $datanascimento); // Corrigido para :da
    $stmt->bindParam(':cp', $cpf);
    $stmt->bindParam(':nu', $numero);
    $stmt->bindParam(':s', $senha);
    $stmt->bindParam(':ci', $codcidade);

    if ($stmt->execute()) {
        echo "Registro incluído com sucesso";
        // Certifique-se de que não há saída HTML ou espaços em branco antes do header
        header("Location: paginacliente.php");
        exit(); // Encerre o script para garantir que o redirecionamento ocorra
    } else {
        echo "Erro ao cadastrar: " . $stmt->errorInfo()[2];
    }
    
}
?>



<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/cadastro.css">
    
    <link rel="stylesheet" href="Projeto/produtos.php">
    <title>Cadastro</title>
</head>

<body>
    <div class="container">
        <div class="form-image">
            <img src="IMAGEM PARA O CONTAINER" alt="">
        </div>
        <div class="form">
            <form method="post">
                <div class="form-header">
                    <div class="title">
                        <h3>Cadastre-se</h3>
                    </div>
                    <div class="login-button">
                        <button><a href="login.php">Entrar</a></button>
                    </div>
                </div>

                <div class="input-group">
                    <div class="input-box">
                        <label for="nome">Nome</label>
                        <input id="nome" type="text" name="nome" placeholder="Nome" required>
                    </div>
<!--
                    <div class="input-box">
                        <label for="sobrenome">Sobrenome</label>
                        <input id="sobrenome" type="text" name="sobrenome" placeholder="Sobrenome" required>
                    </div>
-->                   <div class="input-box">
                        <label for="email">E-mail</label>
                        <input id="email" type="email" name="email" placeholder="E-mail" required>
                    </div>
                    <div class="input-box">
                        <label for="datanascimento">Data de Nascimento</label>
                        <input id="datanascimento" type="date" name="datanascimento" placeholder="Data de Nascimento" required>
                    </div>

                    <div class="input-box">
                        <label for="cpf">CPF</label>
                        <input id="cpf" type="text" name="cpf" placeholder="CPF" required>
                    </div>

                    <div class="input-box">
                        <label for="numero">Celular</label>
                        <input id="numero" type="text" name="numero" placeholder="(xx) xxxxx-xxxx" required>
                    </div>

                    <div class="input-box">
                        <label for="senha">Senha</label>
                        <input id="senha" type="password" name="senha" placeholder="Digite sua Senha" required>
                    </div>

                    <div class="input-box">
                        <label for="codcidade">Cidade</label>
                        <input id="codcidade" type="text" name="codcidade" placeholder="Cidade (Paraná)" required>
                    </div>
                </div>

                <div class="continue-button">
                    <button type="submit" name="bt_cadastrar">Cadastrar</button>
                </div>
            </form>
        </div>
    </div>
</body>

</html>