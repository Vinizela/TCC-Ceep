document.addEventListener("DOMContentLoaded", function () {
    const selectCategoria = document.getElementById("categoria");
    const produtos = document.querySelectorAll(".produto");
  
    selectCategoria.addEventListener("change", function () {
      const categoriaSelecionada = selectCategoria.value;
  
      produtos.forEach((produto) => {
        if (categoriaSelecionada === "todos" || produto.classList.contains(categoriaSelecionada)) {
          produto.style.display = "block";
        } else {
          produto.style.display = "none";
        }
      });
    });
  });