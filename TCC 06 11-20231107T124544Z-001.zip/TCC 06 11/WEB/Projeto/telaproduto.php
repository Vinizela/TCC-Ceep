<?php
include("conexao.php");

if (isset($_GET['id'])) {
    $id_produto = $_GET['id'];

    $query = "SELECT p.*, i.imagem 
              FROM tb_produtos p 
              LEFT JOIN tb_imagens i ON p.codproduto = i.idtb_produtos 
              WHERE p.codproduto = :id";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':id', $id_produto);
    $stmt->execute();
    $produto = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Verifique se o cliente está autenticado
if (isset($_SESSION['cliente_id'])) {
    $cliente_id = $_SESSION['cliente_id'];

    if (isset($_GET['id'])) {
        $id_produto = $_GET['id'];

        $query = "SELECT p.* FROM tb_produtos p WHERE p.codproduto = :id";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':id', $id_produto);
        $stmt->execute();
        $produto = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($produto) {
            $queryAdicionar = "INSERT INTO tb_compras_produtos (quantidade, valorunitario, idtb_produtos, idtb_compras) 
                               VALUES (1, :preco, :produto_id, :cliente_id)";
            $stmtAdicionar = $conn->prepare($queryAdicionar);
            $stmtAdicionar->bindParam(':preco', $produto['preco']);
            $stmtAdicionar->bindParam(':produto_id', $id_produto);
            $stmtAdicionar->bindParam(':cliente_id', $cliente_id);
            $stmtAdicionar->execute();
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Detalhes do Produto</title>
    <link rel="stylesheet" type="text/css" href="css/telaproduto.css">
</head>
<body>
    <header>
        <h3>Detalhes do Produto</h3>
    </header>
    <main>
        <div class="detalhes-produto">
            <?php if (isset($produto)) { ?>
                <div class="produto-imagem">
                    <img src="img/<?php echo $produto['imagem']; ?>" alt="Imagem do Produto">
                </div>
                <div class="produto-info">
                    <h2><?php echo $produto['nome']; ?></h2>
                    <p><?php echo $produto['descricao']; ?></p>
                    <p>Cor: <?php echo $produto['cor']; ?></p>
                    <p>Gênero: <?php echo $produto['genero']; ?></p>
                    <p>Marca: <?php echo $produto['marca']; ?></p>
                    <p>Preço: <?php echo 'R$' . number_format($produto['preco'], 2, ',', '.'); ?></p>

                    <form method="post" action="carrinho.php">
        <label for="tamanho">Escolha o tamanho do tênis:</label>
        <select name="tamanho" id="tamanho">
                            <option value="36">36</option>
                            <option value="37">37</option>
                            <option value="38">38</option>
                            <option value="39">39</option>
                            <option value="40">40</option>
                            <option value="41">41</option>
                            <option value="42">42</option>
                            <option value="43">43</option>
                            <option value="44">44</option>
                        </select>
                    </form>
                    <form id="carrinhoForm">
        <input type="hidden" name="produto_id" value="<?php echo $produto['codproduto']; ?>">
        <button type="button" id="adicionarCarrinho">Adicionar ao Carrinho</button>
    </form>
    </div>
            <?php } else { ?>
                <p>Produto não encontrado.</p>
            <?php } ?>
            <a href="produtos.php">Voltar para o Catálogo</a>
        </div>
    </main>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const botaoAdicionarCarrinho = document.getElementById('adicionarCarrinho');
        botaoAdicionarCarrinho.addEventListener('click', function() {
            const produtoId = document.querySelector('input[name="produto_id"]').value;
            const produtoNome = document.querySelector('h2').innerText;
            const produtoPreco = parseFloat(document.querySelector('p:nth-of-type(5)').innerText.split(' ')[1].replace('R$', '').replace(',', '.'));



            const produto = {
                id: produtoId,
                name: produtoNome,
                price: produtoPreco
            };

            let carrinho = localStorage.getItem("produtosCarrinho");
            carrinho = carrinho ? JSON.parse(carrinho) : [];
            carrinho.push(produto);

            localStorage.setItem("produtosCarrinho", JSON.stringify(carrinho));
            alert('Produto adicionado ao carrinho!');
        });
    });
</script>
</body>
</html>
