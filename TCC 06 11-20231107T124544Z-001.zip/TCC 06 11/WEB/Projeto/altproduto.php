<?php
session_start();
include_once "conexao.php";

$pdo = new PDO("mysql:host=$hostname;dbname=$database_name", $username, $password);

$cod = isset($_GET['codproduto']) ? $_GET['codproduto'] : null; // Puxa o código do produto da URL

if ($cod !== null) {
    $sql = "SELECT p.*, i.imagem 
            FROM tb_produtos p 
            LEFT JOIN tb_imagens i ON p.codproduto = i.idtb_produtos 
            WHERE p.codproduto = :codproduto";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':codproduto', $cod);
    $stmt->execute();
    $produto = $stmt->fetch(PDO::FETCH_ASSOC);
}

if (isset($_POST['bt_atualizar'])) {
    $cor = $_POST["cor"];
    $genero = $_POST["genero"];
    $preco = $_POST["preco"];
    $marca = $_POST["marca"];
    $descricao = $_POST["descricao"];
    $ativoproduto = $_POST["ativoproduto"];
    $nome = $_POST["nome"];
    $tamanho = $_POST["tamanho"];

    $sql = "UPDATE tb_produtos SET 
    cor = :cor,
    genero = :genero,
    preco = :preco,
    marca = :marca,
    descricao = :descricao,
    ativoproduto = :ativoproduto,
    nome = :nome,
    tamanho = :tamanho
    WHERE codproduto = :codproduto";

    $stmt = $pdo->prepare($sql);

    $stmt->bindParam(':codproduto', $cod);
    $stmt->bindParam(':cor', $cor);
    $stmt->bindParam(':genero', $genero);
    $stmt->bindParam(':preco', $preco);
    $stmt->bindParam(':marca', $marca);
    $stmt->bindParam(':descricao', $descricao);
    $stmt->bindParam(':ativoproduto', $ativoproduto);
    $stmt->bindParam(':nome', $nome);
    $stmt->bindParam(':tamanho', $tamanho);

    if ($stmt->execute()) {
        echo "Registro atualizado com sucesso";
        header("Location: paginaadm.php"); // Redirecione para a página de produtos após a atualização
        exit();
    } else {
        echo "Não foi possível atualizar o registro";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alterar Produto</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <main class="formulario">
        <form action="" method="post" enctype="multipart/form-data">
            <p class="titulo_cadastro">Alterar Produto</p>
            <label for="codproduto">Código do Produto:</label>
            <input type="number" name="codproduto" value="<?php echo $produto['codproduto']; ?>" readonly>
            <label for="cor">Cor:</label>
            <input type="text" name="cor" value="<?php echo $produto['cor']; ?>">
            <label for="genero">Gênero:</label>
            <input type="text" name="genero" value="<?php echo $produto['genero']; ?>">
            <label for="preco">Preço:</label>
            <input type="text" name="preco" value="<?php echo $produto['preco']; ?>">
            <label for="marca">Marca:</label>
            <input type="text" name="marca" value="<?php echo $produto['marca']; ?>">
            <label for="descricao">Descrição:</label>
            <input type="text" name="descricao" value="<?php echo $produto['descricao']; ?>">
            <label for="ativoproduto">Ativo do Produto:</label>
            <input type="text" name="ativoproduto" value="<?php echo $produto['ativoproduto']; ?>">
            <label for="nome">Nome:</label>
            <input type="text" name="nome" value="<?php echo $produto['nome']; ?>">
            <label for="tamanho">Tamanho:</label>
            <input type="number" name="tamanho" value="<?php echo $produto['tamanho']; ?>">
            
            <!-- Exibir a imagem associada a este produto -->
            <?php if ($produto && $produto['imagem']) { ?>
                <img src="caminho_para_exibir_imagem/<?php echo $produto['imagem']; ?>" alt="Imagem do Produto">
            <?php } else { ?>
                <p>Nenhuma imagem associada a este produto.</p>
            <?php } ?>
            
            <!-- Permite a atualização da imagem -->
            <label for="imagem">Nova Imagem:</label>
            <input type="file" name="imagem">

            <input type="submit" name="bt_atualizar" value="Atualizar">
        </form>
    </main>
</body>
</html>

