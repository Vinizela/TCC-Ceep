<?php
session_start();
include("conexao.php");

if (isset($_POST['btnSalvar'])) {
    // Verificar se todos os campos estão preenchidos
    if (
        isset($_POST['numero'], $_POST['tipocadastro'], $_POST['ativocliente'], $_POST['nome'], $_POST['cpf'], $_POST['datanascimento'], $_POST['email'], $_POST['senha'])
    ) {
        // Coletar os valores do formulário
        $numero = $_POST['numero'];
        $tipocadastro = $_POST['tipocadastro'];
        $ativocliente = $_POST['ativocliente'];
        $nome = $_POST['nome'];
        $cpf = $_POST['cpf'];
        $datanascimento = $_POST['datanascimento'];
        $complemento = isset($_POST['complemento']) ? $_POST['complemento'] : null;
        $email = $_POST['email'];
        $senha = $_POST['senha'];

        // Se todos os campos necessários estiverem preenchidos
        // Executar a inserção no banco de dados
        $sql = "INSERT INTO tb_clientes (numero, tipocadastro, ativocliente, nome, cpf, datanascimento, complemento, email, senha) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $conn->prepare($sql);
        
        if ($stmt->execute([$numero, $tipocadastro, $ativocliente, $nome, $cpf, $datanascimento, $complemento, $email, $senha])) {
            echo "Inserido com sucesso!";
            header("Location: paginaadm.php");
            exit();
        } else {
            echo "Erro ao inserir cliente";
        }
    } else {
        echo "Por favor, preencha todos os campos obrigatórios.";
    }
}
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Adicionar Clientes</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.js"></script>
</head>
<body>
    <h2>Cadastro de Cliente</h2>
    <form method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label>Número do Cliente</label>
            <input type="number" name="numero" class="form-control col-6" placeholder="Número do Cliente" required>
            <label>Tipo do Cadastro</label>
            <input type="text" name="tipocadastro" class="form-control col-6" placeholder="Tipo do Cadastro" required>
            <label>Ativo Cliente</label>
            <input type="text" name="ativocliente" class="form-control col-6" placeholder="Ativo do Cliente" required>
            <label>Nome</label>
            <input type="text" name="nome" class="form-control col-6" placeholder="Nome do Cliente" required>
            <label>CPF do Cliente</label>
            <input type="number" name="cpf" class="form-control col-6" placeholder="CPF do Cliente" required>
            <label>Data de Nascimento do Cliente</label>
            <input type="date" name="datanascimento" class="form-control col-6" placeholder="Data de Nascimento" required>
            <label>Complemento</label>
            <input type="text" name="complemento" class="form-control col-6" placeholder="Complemento">
            <label>Email</label>
            <input type="text" name="email" class="form-control col-6" placeholder="Email" required>
            <label>Senha do Cliente</label>
            <input type="number" name="senha" class="form-control col-6" placeholder="Senha do Cliente" required>
        </div>
        <button type="submit" name="btnSalvar" class="btn btn-primary">Salvar</button>
    </form>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
</body>
</html>

