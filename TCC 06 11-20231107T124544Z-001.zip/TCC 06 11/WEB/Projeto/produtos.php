<?php
include("conexao.php");

// Consulta ao banco para obter todos os produtos e suas imagens
$query = "SELECT p.*, i.imagem 
          FROM tb_produtos p 
          LEFT JOIN tb_imagens i ON p.codproduto = i.idtb_produtos";
$stmt = $conn->query($query);
$produtos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Catálogo de Produtos</title>
    <link rel="stylesheet" type="text/css" href="css/produto.css">
    <!-- Verifique se o caminho do CSS está correto -->
    <link rel="stylesheet" type="text/css" href="carrinho.php">
</head>
<body>
    <header>
        <h3>Produtos</h3>
    </header>
    <main>
        <div class="catalogo">
            <section class="produto" id="produto">
                <div class="box-container">
                    <?php foreach ($produtos as $produto) { ?>
                        <div class="box">
                            <!-- Correção do caminho das imagens -->
                            <img src="img/<?php echo $produto['imagem']; ?>" alt="Imagem do Produto">
                            <div class="content">
                                <h3><?php echo $produto['nome']; ?></h3>
                                <p><?php echo $produto['descricao']; ?></p>
                                <div class="price"><?php echo 'R$' . number_format($produto['preco'], 2, ',', '.'); ?></div>
                                <p><?php echo $produto['genero']; ?></p>
                                <a href="telaproduto.php?id=<?php echo $produto['codproduto']; ?>" class="btn">Ver Mais</a>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </section>
        </div>
    </main>
</body>
</html>
