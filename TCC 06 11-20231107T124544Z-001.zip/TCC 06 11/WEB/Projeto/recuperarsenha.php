<?php
session_start();
$mensagem = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require_once('conexao.php'); // Inclua o arquivo de conexão

    $cpf = $_POST["cpf"];

    // Verificar se o CPF do usuário existe no banco de dados
    $sql = "SELECT * FROM tb_clientes WHERE cpf = :cpf";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':cpf', $cpf);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($stmt->rowCount() > 0) {
        // Gerar uma nova senha aleatória
        $novaSenha = gerarNovaSenha();
        $senhaHash = md5($novaSenha); // Hash da nova senha

        // Atualizar a senha do usuário no banco de dados
        $sql = "UPDATE tb_clientes SET senha = :senha WHERE cpf = :cpf";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':senha', $senhaHash);
        $stmt->bindParam(':cpf', $cpf);
        $stmt->execute();

        // Enviar a nova senha para o e-mail do cliente
        $to = $user['email']; // E-mail do cliente
        $subject = "Recuperação de senha";
        $message = "Olá " . $user['nome'] . ", sua nova senha é: $novaSenha";
        $headers = "From: seu_email@gmail.com"; // Substitua pelo seu endereço de e-mail do Gmail

        // Configuração do SMTP para o Gmail
        ini_set("SMTP", "smtp.gmail.com");
        ini_set("smtp_port", "587");
        ini_set("sendmail_from", "seu_email@gmail.com");
        ini_set("auth_username", "seu_email@gmail.com");
        ini_set("auth_password", "sua_senha_do_Gmail");
        ini_set("auth", "true");

        if (mail($to, $subject, $message, $headers)) {
            $mensagem = "Nova senha enviada para o e-mail cadastrado.";
        } else {
            $mensagem = "Erro ao enviar nova senha. Entre em contato com o suporte.";
        }
    } else {
        $mensagem = "O CPF fornecido não corresponde a nenhum usuário. Verifique o CPF cadastrado.";
    }
}

function gerarNovaSenha() {
    $tamanho = 10; // Tamanho da nova senha
    $caracteres = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $novaSenha = '';

    for ($i = 0; $i < $tamanho; $i++) {
        $novaSenha .= $caracteres[rand(0, strlen($caracteres) - 1)];
    }

    return $novaSenha;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <!-- Seu código HTML para o cabeçalho aqui -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/login.css">
    <title>Recuperar Senha</title>
</head>
<body>
    <div class="container">
        <div class="form">
            <form action="#" method="post">
                <div class="form-header">
                    <div class="title">
                        <h3>Recuperar Senha</h3>
                    </div>
                </div>

                <!-- Exibir mensagens de sucesso ou erro acima do formulário -->
                <div class="mensagem">
                    <?php echo $mensagem; ?>
                </div>

                <div class="input-group">
                    <div class="input-box">
                        <label for="cpf">CPF</label>
                        <input id="cpf" type="text" name="cpf" placeholder="CPF" required>
                    </div>
                </div>

                <div class="recuperar-button">
                    <button type="submit">Recuperar Senha</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
