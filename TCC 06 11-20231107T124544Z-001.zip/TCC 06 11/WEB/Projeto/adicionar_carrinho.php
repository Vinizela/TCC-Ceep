<?php
session_start();

if (isset($_POST['produto_id'])) {
    // Simular uma adição ao carrinho - você pode modificar este comportamento de acordo com sua lógica
    $_SESSION['carrinho'] = $_POST['produto_id'];
    echo 'sucesso';
} else {
    echo 'erro';
}
?>
