<?php
session_start();
$mensagem = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require_once('conexao.php'); // Inclua o arquivo de conexão

    $email = $_POST["email"];
    $senha = md5($_POST["password"]);

    try {
        $sql = "SELECT * FROM tb_clientes WHERE email = :email AND senha = :senha";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':senha', $senha);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($stmt->rowCount() > 0) {
            $_SESSION['cliente_id'] = $user['codcliente']; // Corrigindo a chave da sessão

            if ($user['ativocliente'] == 'S') {
                if ($user['tipocadastro'] == 'A') {
                    // Redirecionar para a página de administração
                    header("Location: paginaadm.php");
                    exit();
                } elseif ($user['tipocadastro'] == 'C') {
                    $_SESSION['cliente_id'] = $user['codcliente'];
                    // Redirecionar para a página do cliente
                    header("Location: paginacliente.php");
                    exit();
                }
            } else {
                $mensagem = "Sua conta está desativada. Entre em contato com o suporte.";
            }
        } else {
             $mensagem = "Login falhou. Verifique suas credenciais.";
        }

    } catch (PDOException $e) {
        $mensagem = "Erro na consulta: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <!-- Seu código HTML para o cabeçalho aqui -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/login.css">
    <title>Login</title>
</head>
<body>
    <div class="container">
        <div class="form-image">
            <img src="assets/img/undraw_shopping_re_3wst.svg" alt="">
        </div>
        <div class="form">
            <form action="#" method="post">
                <div class="form-header">
                    <div class="title">
                        <h3>Login</h3>
                    </div>
                </div>

                <!-- Exibir mensagens de sucesso ou erro acima do formulário -->
                <div class="mensagem">
                    <?php echo $mensagem; ?>
                </div>

                <div class="input-group">
                    <div class="input-box">
                        <label for="email">E-mail</label>
                        <input id="email" type="email" name="email" placeholder="E-mail" required>
                    </div>
                    <div class="input-box">
                        <label for="password">Senha</label>
                        <input id="password" type="password" name="password" placeholder="Senha" required>
                    </div>
                    <a href="recuperarsenha.php">Esqueceu a senha?</a>

                </div>

                <div class="login-button">
                    <button type="submit">Entrar</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
