<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OZZY</title>
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="produtos.php">
    <link rel="stylesheet" href="cadastro.php">
    <link rel="stylesheet" href="carrinho.php">
    <link rel="stylesheet" href="barrapesquisa.php">
    <link rel="shortcut icon" href="Projeto/img/favicon.ico"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

    <!-- == Seção de Cabeçalho ======= -->
    <header>
        <div id="menu-bar" class="fas fa-bars"></div>
        <a href="#" class="logo">OZZY</a>
        <nav class="navbar">
            <a href="#inicio">Inicio</a>
            <a href="produtos.php">Produtos</a>
            <a href="#review">Review</a>
        </nav>
        <div class="icons">
            <a href="carrinho.php" class="fas fa-shopping-cart"></a>
            <a href="cadastro.php" class="fas fa-user"></a>
        </div>
    </header>

    <!-- == Seção Inicial == -->
    <section class="inicio" id="inicio" style="background-image: url('img/imgindex.jpg'); background-size: cover; background-position: center; height: 100vh; display: flex; align-items: center; justify-content: center;">
        <div class="slide-container">
            <div class="slide">
                <div class="content" style="text-align: center;">
                    <h3>OZZY</h3>
                    <h3>Os Tênis Mais Raros Você Encontra Aqui</h3>
                    <p>Vai um Tênis?</p>
                </div>
            </div>
        </div>
    </section>

    <!-- == Seção de Serviço == -->
    <section class="service">
        <div class="box-container">
            <div class="box">
                <i class="fas fa-shipping-fast"></i>
                <h3>Sem Entrega</h3>
                <p>Não trabalhamos com entrega.</p>
            </div>
            <div class="box">
                <i class="fas fa-undo"></i>
                <h3>Sem devolução</h3>
                <p>Não trabalhamos com devolução.</p>
            </div>
            <div class="box">
                <i class="fas fa-headset"></i>
                <h3>Suporte 24x7</h3>
                <p>Consultar nosso trabalho é o seu direito.</p>
            </div>
        </div>
    </section>

    <!-- == Seção de Lançamentos == -->
    <section class="lançamentos" id="lançamentos">
        <h1 class="heading">Lançamentos</h1>
        <div class="row">
            <div class="image-container">
                <div class="big-image">
                    <img src="IMG10.JPG" class="big-image-3" alt="">
                </div>
            </div>
            <div class="content">
                <h3>Nike Downshifter 11</h3>
                <p>Produzido como um modelo de corrida, o tênis Nike Downshifter 11 foi projetado para uma melhor flexibilidade e ventilação interna, afastando o mau odor característico dos tênis de corrida.</p>
                <div class="price">R$800.00</div>
                <p>Masculino</p>
                <a href="telaproduto.php?id=1" class="btn">Ver Mais</a>
            </div>
        </div>
        <div class="row">
            <div class="image-container">
                <div class="big-image">
                    <img src="img/f-img-3.1.png" class="big-image-3" alt="">
                </div>
            </div>
            <div class="content">
                <h3>Nike Renew Ride 2</h3>
                <p>Considerado um tênis de entrada para os tênis de corrida, o Renew Ride 2 é um modelo que aposta em materiais melhores e na tecnologia que esses materiais podem oferecer.</p>
                <div class="price">R$500.00</div>
                <p>Feminino</p>
                <a href="telaproduto.php?id=2" class="btn">Ver Mais</a>
            </div>
        </div>
        <div class="row">
            <div class="image-container">
                <div class="big-image">
                    <img src="img/f-img-3.1.png" class="big-image-3" alt="">
                </div>
            </div>
            <div class="content">
                <h3>Nike Shox R4</h3>
                <p>O modelo é considerado pela marca referência no mundo street, com amortecedores estruturados em 4 colunas formando um bom drop, que fornecem uma melhor segurança durante o exercício/caminhada.</p>
                <div class="price">R$750.00</div>
                <p>Masculino</p>
                <a href="telaproduto.php?id=3" class="btn">Ver Mais</a>
            </div>
        </div>
        <div class="row">
            <div class="image-container">
                <div class="big-image">
                    <img src="img/f-img-3.1.png" class="big-image-3" alt="">
                </div>
            </div>
            <div class="content">
                <h3>Nike Zoom Fairmont</h3>
                <p>O tênis Nike Zoom Fairmont já começa com o pé direito, usando uma tecnologia da Nike muito cobiçada por diversos atletas: Zoom Air. A tecnologia possibilita uma rápida resposta do calçado à ação do usuário.</p>
                <div class="price">R$910.00</div>
                <p>Feminino</p>
                <a href="telaproduto.php?id=4" class="btn">Ver Mais</a>
            </div>
        </div>
    </section>

    <!-- == Seção de Rodapé == -->
    <section class="footer">
        <div class="box-container">
            <div class="box">
                <h3>Siga-nos</h3>
                <a href="">Facebook</a>
                <a href="">Twitter</a>
                <a href="">Instagram</a>
            </div>
        </div>
    </section>

    <script src="Projeto/script.js"></script>
</body>
</html>
