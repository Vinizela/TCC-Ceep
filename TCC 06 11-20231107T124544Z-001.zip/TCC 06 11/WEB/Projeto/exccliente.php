<?php
session_start();
include_once "conexao.php";

$pdo = new PDO("mysql:host=$hostname;dbname=$database_name", $username, $password);

$cod = isset($_GET['codcliente']) ? $_GET['codcliente'] : null; // Puxa o código do cliente da URL

if ($cod !== null) {
    $sql = "SELECT * FROM tb_clientes WHERE codcliente = :codcliente";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':codcliente', $cod);
    $stmt->execute();
    $cliente = $stmt->fetch(PDO::FETCH_ASSOC);
}

if (isset($_POST['bt_excluir'])) {
    $sql = "DELETE FROM tb_clientes WHERE codcliente = :codcliente";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':codcliente', $cod);

    if ($stmt->execute()) {
        echo "Cliente excluído com sucesso";
        header("Location: paginaadm.php"); // Redirecione para a página de administração após a exclusão
        exit();
    } else {
        echo "Não foi possível excluir o cliente";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Excluir Cliente</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <main class="formulario">
        <form action="" method="post">
            <p class="titulo_cadastro">Excluir Cliente</p>
            <label for="codcliente">Código do Cliente:</label>
            <input type="number" name="codcliente" value="<?php echo $cliente['codcliente']; ?>" readonly>
            <label for="nome">Nome:</label>
            <input type="text" name="nome" value="<?php echo $cliente['nome']; ?>">
            <label for="nome">Tipo do Cadastro:</label>
            <input type="text" name="tipocadastro" value="<?php echo $cliente['tipocadastro']; ?>">
            <label for="nome">Ativo Cliente:</label>
            <input type="text" name="ativocliente" value="<?php echo $cliente['ativocliente']; ?>">
            <!-- Adicione outros campos de cliente, se necessário -->
            <button type="button" onclick="confirmarExclusao()">Excluir</button>
            <script>
                function confirmarExclusao() {
                    if (confirm("Tem certeza de que deseja excluir este cliente?")) {
                        document.getElementById('bt_excluir').click();
                    }
                }
            </script>
        </form>
        <form action="" method="post" style="display: none;">
            <button type="submit" name="bt_excluir" id="bt_excluir"></button>
        </form>
    </main>
</body>
</html>
