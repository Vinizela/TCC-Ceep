<?php
session_start();
include_once "./conexao.php";

$pdo = conectar();
$cod = $_GET['cod'];

    $sql = "SELECT * FROM tb_cidades WHERE codcidade = :codcidade";
    $stmc = $pdo->prepare($sql);
    $stmc->bindParam(':codcidade', $cod);
    $stmc->execute();
    // Buscando todas as linhas da tabela
    $chave = $stmc->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/cabecalho_site.css">
    <link rel="stylesheet" href="../css/footer.css">
    <link rel="stylesheet" href="../css/cadastro.css">
</head>
<body>
    <main class="">
        <form action="" method="post" enctype="multipart/form-data" class="formulario" action="action_page.php">
            <p class="titulo_cadastro">Alterar Cidades</p>

            <label class="label" for="nomecidade">Nome da Cidade:</label>
            <input class="input" id="nomecidade" name="nomecidade" type="text" value="<?php  echo $chave['nomecidade']; ?>">
            
            <label class="label" for="estado">Estado:</label>
            <input class="input" id="estado" name="estado" type="text" value="<?php  echo $chave['estado'] ?>">

            <input class="input btn_enviar" name="bt_atualizar" value="Atualizar" type="submit">
        </form>
    </main>
</body>
</html>

<?php
if (isset($_POST['bt_atualizar'])) {
// faça o teste se o botão foi pressionado
// receba o conteudo digitado no input
// deve ser feito um para cada input
    $nomecidade = $_POST["nomecidade"];
    $estado = $_POST["estado"];

// validação simples (opcional) FAZER PARA VALORES NOT NULL (TALVEZ)
// aqui verificamos se tem algum conteudo no input


// criando o sql do programa e colocando as
// variaveis magicas                    NECESSITA BANCO

    $sql = "UPDATE tb_cidades SET nomecidade = :nomecidade, estado = :estado  WHERE codcidade = :codcidade";


// preparando o sql para ser processado
    $stmt = $pdo->prepare($sql);

    //substituindo as variaveis magicas por dados digitados
    $stmt->bindParam(':codcidade', $cod);
    $stmt->bindParam(':nomecidade', $nomecidade);
    $stmt->bindParam(':estado', $estado);

    // se o comando der certo
    if ($stmt->execute()) {
        //mostra mensagem de realização do comando
        echo "Registro inserido com sucesso";
        //mandar pra outra pagina
        //header(Location: pagina.php);
    } else {
        echo "Não foi possivel inserir o registro";
    }
}
?>

    