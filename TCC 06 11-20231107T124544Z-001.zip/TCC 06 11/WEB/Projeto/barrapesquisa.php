<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Barra de Pesquisa de Produtos</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons" />
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 30px;
        }
        .form-select, .form-control, button {
            display: inline-block;
            margin-right: 10px;
            width: 30%;
        }
        button {
            background-color: #007BFF;
            border: none;
            color: #fff;
            font-size: 24px;
        }
        button:hover {
            background-color: #0056b3;
        }
        h2 {
            color: #333;
        }
        h3 {
            color: #007BFF;
        }
        p {
            font-size: 18px;
            color: #333;
        }
        hr {
            border-color: #ddd;
        }
    </style>
</head>
<body>
    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <h2 class="mt-3">Barra de Pesquisa</h2>
                <form method="GET" class="input-group">
                    <select name="tipo_pesquisa" class="form-select">
                        <option value="nome">Nome</option>
                        <option value="marca">Marca</option>
                        <option value="cor">Cor</option>
                        <option value="genero">Gênero</option>
                    </select>
                    <input type="text" name="pesquisa" class="form-control form-control-lg">
                    <button type="submit"><i class="material-icons">search</i></button>
                </form>
                <?php 
                if ($_SERVER['REQUEST_METHOD'] === "GET") {
                    if (isset($_GET['tipo_pesquisa']) && isset($_GET['pesquisa']) && !empty($_GET['pesquisa'])) {
                        $tipo_pesquisa = $_GET['tipo_pesquisa'];
                        $pesquisa = $_GET['pesquisa'] . "%";
                        
                        // Construir a consulta SQL com base no tipo de pesquisa
                        $sql = "SELECT * FROM tb_produtos WHERE ";
                        if ($tipo_pesquisa == "nome") {
                            $sql .= "nome LIKE :pesquisa";
                        } else if ($tipo_pesquisa == "marca") {
                            $sql .= "marca LIKE :pesquisa";
                        } else if ($tipo_pesquisa == "cor") {
                            $sql .= "cor LIKE :pesquisa";
                        } else if ($tipo_pesquisa == "genero") {
                            $sql .= "genero LIKE :pesquisa";
                        }

                        // Executar a consulta
                        $stmt = $pdo->prepare($sql);
                        $stmt->bindParam(":pesquisa", $pesquisa);
                        $stmt->execute();
                        
                        $resultado = $stmt->fetchAll(PDO::FETCH_ASSOC);

                        // Exibir resultados
                        if (count($resultado) > 0) {
                            echo "<h3>Resultado da pesquisa</h3>";

                            foreach ($resultado as $produto) {
                                echo "<p>Nome: " . $produto['nome'] . "</p>";
                                echo "<p>Marca: " . $produto['marca'] . "</p>";
                                echo "<p>Cor: " . $produto['cor'] . "</p>";
                                echo "<p>Preço: R$" . $produto['preco'] . "</p>";
                                echo "<p>Gênero: " . $produto['genero'] . "</p>";
                                echo '<hr>';
                            }
                        } else {
                            echo "<h3>Nenhum resultado encontrado</h3>";
                        }
                    }
                }
                ?>
            </div>
        </div>
    </div>
</body>
</html>
