<?php
session_start();
include_once "./conexao.php";

$pdo = conectar();
//traz dados
$sql = "SELECT * FROM tb_clientes";
$stmc = $pdo -> prepare($sql);
$stmc -> execute();
//buscando todas as linhas da tabela
$resuldato = $stmc ->fetchAll(PDO::FETCH_ASSOC);

//buscando um unico registro
//$resuldato = $stmc ->fetch(PDO::FETCH_ASSOC);
?> 

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/cabecalho_site.css">
    <link rel="stylesheet" href="../css/footer.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.js"></script>
    <script src="js/jquery.js"></script>
</head>
<body>
    <main>
        <table class="table table-striped table-bordered">
            <tr>
                <!-- titulos -->
                <th>codcliente</th>
                <th>numero</th>
                <th>tipocadastro</th>
                <th>ativocliente</th>
                <th>nome</th>
                <th>cpf</th>
                <th>datanascimento</th>
                <th>complemento</th>
                <th>email</th>
                <th>senha</th>
            </tr>

                <?php foreach ($resuldato as $cliente) { ?>
                    <tr>
                        <!-- coluna com informacao -->
                        <td> <?php echo $cliente['codcliente']; ?> </td>
                        <td> <?php echo $cliente['numero']; ?> </td>
                        <td> <?php echo $cliente['tipocadastro']; ?> </td>
                        <td> <?php echo $cliente['ativocliente']; ?> </td>
                        <td> <?php echo $cliente['nome']; ?> </td>
                        <td> <?php echo $cliente['cpf']; ?> </td>
                        <td> <?php echo $cliente['datanascimento']; ?> </td>
                        <td> <?php echo $cliente['complemento']; ?> </td>
                        <td> <?php echo $cliente['email']; ?> </td>
                        <td> <?php echo $cliente['senha']; ?> </td>
                        <td><a href="altcliente.php?cod=<?php echo $cliente['codcliente']?>" class="btn btn-danger">alterar</a> <a href="exccliente.php?cod=<?php echo $cliente['codcliente']?>" class="btn btn-danger">excluir</a></td>
                    </tr>
                <?php } ?>
        </table>
    </main>

</body>
</html>