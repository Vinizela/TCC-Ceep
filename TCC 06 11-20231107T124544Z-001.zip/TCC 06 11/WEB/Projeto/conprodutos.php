<?php
session_start();
include("conexao.php");

// Verifica se a conexão está estabelecida corretamente
if ($conn) 
    // Trazendo dados
    $sql = "SELECT * FROM tb_produtos";
    $stmc = $conn->prepare($sql);
    $stmc->execute();
    $resuldato = $stmc->fetchAll(PDO::FETCH_ASSOC);

    if ($resuldato) 
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/cabecalho_site.css">
    <link rel="stylesheet" href="../css/footer.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.js"></script>
    <script src="js/jquery.js"></script>
</head>
<body>
    <main>
        <table class="table table-striped table-bordered">
            <tr>
                <!-- títulos -->
                <th>codproduto</th>
                <th>cor</th>
                <th>genero</th>
                <th>preco</th>
                <th>marca</th>
                <th>descricao</th>
                <th>ativoproduto</th>
                <th>nome</th>
                <th>tamanho</th>
            </tr>

                <?php foreach ($resuldato as $produto) { ?>
                    <tr>
                        <!-- coluna com informação -->
                        <td> <?php echo $produto['codproduto']; ?> </td>
                        <td> <?php echo $produto['cor']; ?> </td>
                        <td> <?php echo $produto['genero']; ?> </td>
                        <td> <?php echo $produto['preco']; ?> </td>
                        <td> <?php echo $produto['marca']; ?> </td>
                        <td> <?php echo $produto['descricao']; ?> </td>
                        <td> <?php echo $produto['ativoproduto']; ?> </td>
                        <td> <?php echo $produto['nome']; ?> </td>
                        <td> <?php echo $produto['tamanho']; ?> </td>
                        <td>
    <a href="altproduto.php?codproduto=<?php echo $produto['codproduto']?>" class="btn btn-danger">alterar</a>
    <a href="excproduto.php?codproduto=<?php echo $produto['codproduto']?>" class="btn btn-danger">excluir</a>
</td>
                <?php } ?>
        </table>
    </main>
</body>
</html>
