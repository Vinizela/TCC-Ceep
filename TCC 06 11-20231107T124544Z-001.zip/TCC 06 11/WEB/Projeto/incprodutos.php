<?php
session_start();
$hostname = "localhost:3307";
$database_name = "ozzy_bdd";
$username = "root";
$password = '';

if (isset($_POST['btnSalvar'])) {
    $codproduto = $_POST['codproduto'] ?? '';
    $cor = $_POST['cor'] ?? '';
    $genero = $_POST['genero'] ?? '';
    $preco = $_POST['preco'] ?? '';
    $marca = $_POST['marca'] ?? '';
    $descricao = $_POST['descricao'] ?? '';
    $ativoproduto = $_POST['ativoproduto'] ?? '';
    $nome = $_POST['nome'] ?? '';
    $tamanho = $_POST['tamanho'] ?? '';

    $imagem = $_FILES['imagem'];
    $imagem_nome = $imagem['name'];
    $imagem_tmp = $imagem['tmp_name'];
    $imagem_destino = 'C:/xampp/htdocs/Projeto/img/' . $imagem_nome;

    if (move_uploaded_file($imagem_tmp, $imagem_destino)) {
        try {
            $conn = new PDO("mysql:host=$hostname;dbname=$database_name", $username, $password);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $sql = "INSERT INTO tb_produtos (codproduto, cor, genero, preco, marca, descricao, ativoproduto, nome, tamanho) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            $stmt = $conn->prepare($sql);

            if ($stmt->execute([$codproduto, $cor, $genero, $preco, $marca, $descricao, $ativoproduto, $nome, $tamanho])) {
                // Obtém o ID do último produto inserido
                $last_id = $conn->lastInsertId();
                
                // Insere o nome da imagem na tabela tb_imagens vinculada ao produto
                $sql_imagem = "INSERT INTO tb_imagens (imagem, idtb_produtos) VALUES (?, ?)";
                $stmt_imagem = $conn->prepare($sql_imagem);
                
                if ($stmt_imagem->execute([$imagem_nome, $last_id])) {
                    echo "Produto e imagem inseridos com sucesso!";
                    header("Location: paginaadm.php");
                    exit;
                } else {
                    echo "Erro ao inserir imagem";
                }
            } else {
                echo "Erro ao inserir produto";
            }
        } catch (PDOException $e) {
            echo "Erro na conexão: " . $e->getMessage();
        }
    } else {
        echo "Erro no upload do arquivo";
    }
}
?>



<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Adicionar Produtos</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.js"></script>
</head>
<body>
    <h2>Cadastro de Produto</h2>
    <form method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label>Código do Produto</label>
            <input type="number" name="codproduto" class="form-control col-6" placeholder="Código do Produto" required>
            <!-- Adicione os outros campos para inserção de dados -->
            <label>Cor do Produto</label>
            <input type="text" name="cor" class="form-control col-6" placeholder="Cor do Produto" required>
            <label>Gênero do Produto</label>
            <input type="text" name="genero" class="form-control col-6" placeholder="Gênero do Produto" required>
            <label>Preço do Produto</label>
            <input type="number" name="preco" class="form-control col-6" placeholder="Preço do Produto" required>
            <label>Marca do Produto</label>
            <input type="text" name="marca" class="form-control col-6" placeholder="Marca do Produto" required>
            <label>Descrição do Produto</label>
            <input type="text" name="descricao" class="form-control col-6" placeholder="Descrição do Produto" required>
            <label>Produto Ativo</label>
            <input type="text" name="ativoproduto" class="form-control col-6" placeholder="Informe se o produto está ativo" required>
            <label>Nome do Produto</label>
            <input type="text" name="nome" class="form-control col-6" placeholder="Nome do Produto" required>
            <label>Tamanho do Produto</label>
            <input type="number" name="tamanho" class="form-control col-6" placeholder="Tamanho do Produto" required>
            <!-- Fim dos campos para inserção de dados -->
            <div class="form-group">
                <label>Imagem do Produto</label>
                <input type="file" name="imagem" class="form-control col-6" required>
            </div>
        </div>
        <button type="submit" name="btnSalvar" class="btn btn-primary">Salvar</button>
    </form>
    <!-- Seus scripts JavaScript -->
</body>
</html>
