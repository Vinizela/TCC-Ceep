<?php
session_start();
include("conexao.php");

$codcompra = isset($_GET['codcompra']) ? $_GET['codcompra'] : null;

if ($codcompra) {
    try {
        $sql = "DELETE FROM tb_compras WHERE codcompra = :codcompra";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':codcompra', $codcompra);
        $stmt->execute();

        echo "Compra excluída com sucesso.";
    } catch (PDOException $e) {
        echo "Erro ao excluir a compra: " . $e->getMessage();
    }
} else {
    echo "Código da compra não especificado.";
}
?>


<script>
    // Função para confirmar a exclusão da compra
    function confirmarExclusao() {
        // Exibe um alerta de confirmação
        var confirmar = confirm("Tem certeza de que deseja excluir esta compra?");
        if (confirmar) {
            window.location = 'exccompra.php?codcompra=<?php echo $codcompra; ?>&confirm=1';
        }
    }

    // Chama a função ao carregar a página
    confirmarExclusao();
</script>
