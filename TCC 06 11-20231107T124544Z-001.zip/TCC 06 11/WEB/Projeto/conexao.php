<?php
$hostname = "localhost:3307";
$database_name = "ozzy_bdd";
$username = "root";
$password = '';

try {
    $conn = new PDO("mysql:host=$hostname;dbname=$database_name", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    return $conn;
} catch (PDOException $e) {
    echo "Erro na conexão: " . $e->getMessage();
}
?>
