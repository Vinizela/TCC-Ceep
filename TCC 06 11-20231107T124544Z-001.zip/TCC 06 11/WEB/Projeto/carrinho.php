<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Carrinho de Compras</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      display: flex;
      flex-direction: column;
      align-items: center;
    }
    h1 {
      text-align: center;
      width: 100%;
      margin-top: 0;
      margin-bottom: 10px;
    }
    .productList {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      width: 80%;
      margin-bottom: 10px;
    }
    .productList table {
      width: 70%;
    }
    .productList .productSelection {
      display: flex;
      flex-direction: column;
      align-items: center;
      margin-right: 25px;
    }
    .productSelection button {
      border: 1px solid #000;
      border-radius: 50%;
      width: 20px;
      height: 20px;
      background-color: #ffffff;
      color: #000;
      cursor: pointer;
      margin-bottom: 15px;
      transition: background-color 0.3s ease-in-out;
    }
    .productSelection button.selected {
      background-color: #0c0ce94d;
    }
    table {
      border-collapse: collapse;
      margin-bottom: 20px;
      width: 100%;
    }
    table, th, td {
      border: 1px solid #ccc;
    }
    th, td {
      padding: 8px;
      text-align: left;
      vertical-align: top;
    }
    .productSelection {
      margin-right: 15px;
    }
    th:nth-child(1),
    td:nth-child(1) {
      background-color: transparent;
      color: transparent;
      border-color: transparent;
      padding: 0;
      width: 25px;
    }
    th:nth-child(1) button {
      margin-bottom: 15px;
    }
    th:nth-child(1) button:last-child {
      margin-bottom: 0;
    }
    .totalTable {
      border-collapse: collapse;
      width: 30%;
      float: left;
    }
    .totalTable th,
    .totalTable td {
      border: 1px solid #ccc;
      padding: 8px;
      text-align: left;
    }
  </style>
</head>
<body>
  <h1>Seu Carrinho</h1>
  <div class="productList">
    <table>
      <thead>
        <tr>
          <th>Botão</th>
          <th>Imagem</th>
          <th>Nome do Produto</th>
          <th>Tamanho</th>
          <th>Quantidade</th>
          <th>Preço Total</th>
          <th>Ações</th>
        </tr>
      </thead>
      <tbody id="cartList">
        <!-- Itens do carrinho aparecerão aqui -->
      </tbody>
    </table>
    <table class="totalTable">
      <thead>
        <tr>
          <th>Nome do Produto</th>
          <th>Preço Total dos Produtos Selecionados</th>
        </tr>
      </thead>
      <tbody id="newTable">
        <!-- Resultados da multiplicação aparecerão aqui -->
      </tbody>
      <tfoot id="totalSum">
        <tr>
          <td><strong>Total:</strong></td>
          <td id="sumAmount"></td>
        </tr>
      </tfoot>
    </table>
  </div>

  <script>
    document.addEventListener("DOMContentLoaded", function() {
  const cartList = document.getElementById("cartList");
  const newTable = document.getElementById("newTable");
  const sumAmount = document.getElementById("sumAmount");
  let produtosCarrinho = JSON.parse(localStorage.getItem("produtosCarrinho")) || [];

  function renderizarCarrinho() {
    cartList.innerHTML = "";
    newTable.innerHTML = "";
    sumAmount.textContent = "";

    let total = 0;

    produtosCarrinho.forEach((produto, index) => {
      const tr = document.createElement('tr');
      const btnColumn = document.createElement('td');
      const selectButton = document.createElement('button');
      selectButton.textContent = '!';
      selectButton.classList.add('productButton');
      selectButton.addEventListener('click', function() {
        produto.selected = !produto.selected;

        if (produto.selected) {
          const existsInNewTable = Array.from(newTable.getElementsByTagName('tr')).find((element) => {
            return element.firstChild.textContent === produto.name;
          });

          if (!existsInNewTable) {
            const selectedTr = document.createElement('tr');
            const nomeTd = document.createElement('td');
            nomeTd.textContent = produto.name;
            selectedTr.appendChild(nomeTd);

            const multiplicacaoTd = document.createElement('td');
            multiplicacaoTd.textContent = `R$ ${produto.price * (produto.quantity || 1)}`;
            selectedTr.appendChild(multiplicacaoTd);

            newTable.appendChild(selectedTr);
            total += produto.price * (produto.quantity || 1);
            sumAmount.textContent = `R$ ${total}`;
          }
        } else {
          const toBeRemoved = Array.from(newTable.getElementsByTagName('tr')).find((element) => {
            return element.firstChild.textContent === produto.name;
          });
          if (toBeRemoved) {
            toBeRemoved.remove();
            total -= produto.price * (produto.quantity || 1);
            sumAmount.textContent = `R$ ${total}`;
          }
        }

        selectButton.classList.toggle('selected');
        renderizarCarrinho();
        atualizarLocalStorage();
      });

      btnColumn.appendChild(selectButton);
      const imagemTd = document.createElement('td');
      imagemTd.innerHTML = `<img src="${produto.imagem}" style="width: 100px;">`;
      const nomeTd = document.createElement('td');
      nomeTd.textContent = produto.name;
      const tamanhoTd = document.createElement('td');
      tamanhoTd.textContent = produto.size;
      const quantidadeTd = document.createElement('td');
      quantidadeTd.textContent = produto.quantity || 1;
      const precoTotalTd = document.createElement('td');
      precoTotalTd.textContent = `R$ ${produto.price * (produto.quantity || 1)}`;
      const acoesTd = document.createElement('td');
      const btnAdicionar = document.createElement('button');
      btnAdicionar.textContent = '+';
      btnAdicionar.addEventListener('click', function() {
        produto.quantity = (produto.quantity || 0) + 1;
        quantidadeTd.textContent = produto.quantity;
        precoTotalTd.textContent = `R$ ${produto.price * produto.quantity}`;
        total += produto.price;
        sumAmount.textContent = `R$ ${total}`;
        atualizarLocalStorage();
      });

      const btnRemover = document.createElement('button');
      btnRemover.textContent = '-';
      btnRemover.addEventListener('click', function() {
        if (produto.quantity > 1) {
          produto.quantity = (produto.quantity || 0) - 1;
          quantidadeTd.textContent = produto.quantity;
          precoTotalTd.textContent = `R$ ${produto.price * produto.quantity}`;
          total -= produto.price;
          sumAmount.textContent = `R$ ${total}`;
          atualizarLocalStorage();
        }
      });

      const btnRemoverCompleto = document.createElement('button');
      btnRemoverCompleto.textContent = 'Remover';
      btnRemoverCompleto.addEventListener('click', function() {
        total -= produto.price * (produto.quantity || 1);
        sumAmount.textContent = `R$ ${total}`;
        produtosCarrinho = produtosCarrinho.filter((_, i) => i !== index);
        renderizarCarrinho();
        atualizarLocalStorage();
      });

      acoesTd.appendChild(btnAdicionar);
      acoesTd.appendChild(btnRemover);
      acoesTd.appendChild(btnRemoverCompleto);

      tr.appendChild(btnColumn);
      tr.appendChild(imagemTd);
      tr.appendChild(nomeTd);
      tr.appendChild(tamanhoTd);
      tr.appendChild(quantidadeTd);
      tr.appendChild(precoTotalTd);
      tr.appendChild(acoesTd);
      cartList.appendChild(tr);

      if (produto.selected) {
        const tr = document.createElement('tr');
        const nomeTd = document.createElement('td');
        nomeTd.textContent = produto.name;
        tr.appendChild(nomeTd);
        const multiplicacaoTd = document.createElement('td');
        multiplicacaoTd.textContent = `R$ ${produto.price * (produto.quantity || 1)}`;
        tr.appendChild(multiplicacaoTd);
        newTable.appendChild(tr);
      }
    });

    // Soma total dos produtos selecionados
    const somaTotal = calcularSomaTotal();
    sumAmount.textContent = `Soma Total: R$ ${somaTotal.toFixed(2)}`;
  }

  function atualizarLocalStorage() {
    localStorage.setItem("produtosCarrinho", JSON.stringify(produtosCarrinho));
  }

  function calcularSomaTotal() {
    let somaTotal = 0;
    const totalProdutosSelecionados = document.querySelectorAll('#newTable tr td:nth-child(2)');

    totalProdutosSelecionados.forEach((preco) => {
      const valorTexto = preco.textContent.replace('R$ ', '');
      const valorNumerico = parseFloat(valorTexto);
      somaTotal += valorNumerico;
    });

    return somaTotal;
  }

  renderizarCarrinho();
});
  </script>
</body>
</html>
