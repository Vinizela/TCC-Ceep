<?php
session_start();
include_once "./conexao.php";

$pdo = conectar();

$cod = $_GET['cod'];
$sql = "SELECT * FROM tb_cidades WHERE codcidade = :cod";
$stmc = $pdo -> prepare($sql);
$stmc -> bindParam(':cod', $cod);
$stmc -> execute();

if($stmc->rowCount() > 0) {
    $sqlex = "DELETE FROM tb_cidades WHERE codcidade = $cod";
    $stmex = $pdo -> query($sqlex);
    echo 'autor excluido com sucesso';
}else{
    echo 'autor nao encontrado';
}

header('location: excccidades.php');
?> 