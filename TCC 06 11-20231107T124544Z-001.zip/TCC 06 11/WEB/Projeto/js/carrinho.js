<script>
  document.addEventListener("DOMContentLoaded", function () {
    const carrinho = document.querySelector("table");
    const subTotalElement = document.querySelector(".info span:first-child");
    const totalElement = document.querySelector(".info span:last-child");

    // Produtos disponíveis (pode adicionar mais)
    const produtos = [
      {
        nome: "Produto 1",
        preco: 120,
        quantidade: 0,
      },
    ];

    // Função para atualizar o carrinho
    function atualizarCarrinho() {
      carrinho.innerHTML = `
        <thead>
          <tr>
            <th>Produto</th>
            <th>Preço</th>
            <th>Quantidade</th>
            <th>Total</th>
          </tr>
        </thead>
        <tbody>
          ${produtos
            .map(
              (produto, index) => `
            <tr>
              <td>${produto.nome}</td>
              <td>R$ ${produto.preco.toFixed(2)}</td>
              <td>
                <button class="decrement" data-index="${index}">-</button>
                <span>${produto.quantidade}</span>
                <button class="increment" data-index="${index}">+</button>
              </td>
              <td>R$ ${(produto.preco * produto.quantidade).toFixed(2)}</td>
            </tr>
          `
            )
            .join("")}
        </tbody>
      `;

      // Adicionar event listeners para os botões de incremento e decremento
      const incrementButtons = document.querySelectorAll(".increment");
      const decrementButtons = document.querySelectorAll(".decrement");

      incrementButtons.forEach((button) => {
        button.addEventListener("click", (e) => {
          const index = e.target.getAttribute("data-index");
          produtos[index].quantidade++;
          atualizarCarrinho();
        });
      });

      decrementButtons.forEach((button) => {
        button.addEventListener("click", (e) => {
          const index = e.target.getAttribute("data-index");
          if (produtos[index].quantidade > 0) {
            produtos[index].quantidade--;
            atualizarCarrinho();
          }
        });
      });

      // Calcular o subtotal e o total
      const subTotal = produtos.reduce(
        (total, produto) => total + produto.preco * produto.quantidade,
        0
      );
      const total = subTotal;

      subTotalElement.textContent = `R$ ${subTotal.toFixed(2)}`;
      totalElement.textContent = `R$ ${total.toFixed(2)}`;
    }

    atualizarCarrinho();
  });
</script>
