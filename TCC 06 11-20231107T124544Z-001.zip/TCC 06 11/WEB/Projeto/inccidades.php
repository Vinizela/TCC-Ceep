<?php
include_once("conexao.php");

$pdo = conectar();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Adicionar Cidades</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.js"></script>
</head>
<body>
    <h2>Cadastro de Cidade</h2>
    <form method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label>Código da Cidade</label>
            <input type="number" name="codcidade" class="form-control col-6" placeholder="Código da Cidade" required>
            <label>Nome da Cidade</label>
            <input type="text" name="nomecidade" class="form-control col-6" placeholder="Nome da Cidade" required>
            <label>Estado</label>
            <input type="text" name="estado" class="form-control col-6" placeholder="Estado" required>
        </div>
        <button type="submit" name="btnSalvar" class="btn btn-primary">Salvar</button>
    </form>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
</body>
</html>

<?php
if(isset($_POST['btnSalvar'])){
    $codcidade = $_POST['codcidade'];
    $nomecidade = $_POST['nomecidade'];
    $estado = $_POST['estado'];

    $sql = "INSERT INTO tb_cidades (codcidade, nomecidade, estado)
            VALUES (?, ?, ?)";

    $stmt = $pdo->prepare($sql);

    if($stmt->execute([$codcidade, $nomecidade, $estado])){
        echo "Inserido com sucesso!";
        header("Location: index.php");
    } else {
        echo "Erro ao inserir produto";
    }
}
?>
