<?php
session_start();
include_once "conexao.php";

$pdo = new PDO("mysql:host=$hostname;dbname=$database_name", $username, $password);

$cod = isset($_GET['codcliente']) ? $_GET['codcliente'] : null; // Puxa o código do cliente da URL

if ($cod !== null) {
    $sql = "SELECT * FROM tb_clientes WHERE codcliente = :codcliente";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':codcliente', $cod);
    $stmt->execute();
    $cliente = $stmt->fetch(PDO::FETCH_ASSOC);
}

if (isset($_POST['bt_atualizar'])) {
    $tipocadastro = $_POST["tipocadastro"];
    $ativocliente = $_POST["ativocliente"];

    $sql = "UPDATE tb_clientes SET 
    tipocadastro = :tipocadastro,
    ativocliente = :ativocliente
    WHERE codcliente = :codcliente";

    $stmt = $pdo->prepare($sql);

    $stmt->bindParam(':codcliente', $cod);
    $stmt->bindParam(':tipocadastro', $tipocadastro);
    $stmt->bindParam(':ativocliente', $ativocliente);

    if ($stmt->execute()) {
        echo "Registro atualizado com sucesso";
        header("Location: paginaadm.php"); // Redirecione para a página de clientes após a atualização
        exit();
    } else {
        echo "Não foi possível atualizar o registro";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alterar Cliente</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <main class="formulario">
        <form action="" method="post">
            <p class="titulo_cadastro">Alterar Cliente</p>
            <label for="codcliente">Código do Cliente:</label>
            <input type="number" name="codcliente" value="<?php echo $cliente['codcliente']; ?>" readonly>
            <label for="tipocadastro">Tipo do Cadastro:</label>
            <input type="text" name="tipocadastro" value="<?php echo $cliente['tipocadastro']; ?>">
            <label for="ativocliente">Ativo Cliente:</label>
            <input type="text" name="ativocliente" value="<?php echo $cliente['ativocliente']; ?>">
            <input type="submit" name="bt_atualizar" value="Atualizar">
        </form>
    </main>
</body>
</html>
