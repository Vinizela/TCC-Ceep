<?php
function brmy($data)
{
    list($dia, $mes, $ano) = explode("/", $data);
    return "$dia/$mes/$ano";
}


function mybr($data)
{
    $datam = implode("-", array_reverse(explode("/", $data)));
    return $datam;
}
/*
// Aqui exemplo de uso o primeiro tem exemplo vindo do form oara o banco Mysql
$datab = "13/08/2023";
// Aqui vindo do banco para Tela, Form, etc
$datam = "2023-08-13";

echo "Data BR para Mysql:  " . mybr($datam) . "<br><bR>";

echo "Data BR para Mysql:  " . brmy($datab) . "<br><bR>";
*/