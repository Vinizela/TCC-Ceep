<?php
session_start();
require_once("conexao.php");

if (!isset($_SESSION['cliente_id']) || $_SESSION['cliente_id'] == null) {
    header("Location: login.php");
    exit();
}

$mensagem = "";

// Listar os produtos da tabela
try {
    $sql = "SELECT * FROM tb_produtos";
    $stmt = $conn->query($sql);
    $produtos = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $mensagem = "Erro ao listar os produtos: " . $e->getMessage();
}

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OZZY</title>
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="produtos.php">
    <link rel="stylesheet" href="cadastro.php">
    <link rel="stylesheet" href="carrinho.php">
    <link rel="shortcut icon" href="Projeto/img/favicon.ico"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

    

    <!-- Tabela de Produtos com Opções de Edição e Exclusão -->
    <section class="produto-list">
        <h1 class="heading">Lista de Produtos</h1>
        <a href="incprodutos.php" >Adicionar Produtos</a>
        <div class="icons">
            <a href="index.php" class="fas fa-sign-out-alt"> Sair da Conta</a>
        </div>
        <table>
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>Cor</th>
                    <th>Gênero</th>
                    <th>Preço</th>
                    <th>Marca</th>
                    <th>Descrição</th>
                    <th>Tamanho</th>
                    <th>Opções</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($produtos as $produto) : ?>
                    <tr>
                        <td><?= $produto['nome'] ?></td>
                        <td><?= $produto['cor'] ?></td>
                        <td><?= $produto['genero'] ?></td>
                        <td>R$<?= number_format($produto['preco'], 2, ',', '.') ?></td>
                        <td><?= $produto['marca'] ?></td>
                        <td><?= $produto['descricao'] ?></td>
                        <td><?= $produto['tamanho'] ?></td>
                        <td>
                            <a href="altproduto.php?codproduto=<?= $produto['codproduto'] ?>">Editar</a>
                            <a href="excproduto.php?codproduto=<?= $produto['codproduto'] ?>">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </section>

    <!-- Tabela de Clientes com Opções de Edição e Exclusão -->
<section class="cliente-list">
    <h1 class="heading">Lista de Clientes</h1>
    <table>
        <thead>
            <tr>
                <th>Nome</th>
                <th>CPF</th>
                <th>Data de Nascimento</th>
                <th>Email</th>
                <th>Ativo</th>
                <th>Opções</th>
            </tr>
        </thead>
        <tbody>
            <?php
            try {
                $sql = "SELECT * FROM tb_clientes";
                $stmt = $conn->query($sql);
                $clientes = $stmt->fetchAll(PDO::FETCH_ASSOC);

                foreach ($clientes as $cliente) :
            ?>
                <tr>
                    <td><?= $cliente['nome'] ?></td>
                    <td><?= $cliente['cpf'] ?></td>
                    <td><?= $cliente['datanascimento'] ?></td>
                    <td><?= $cliente['email'] ?></td>
                    <td><?= $cliente['ativocliente'] == 'S' ? 'Sim' : 'Não' ?></td>
                    <td>
                        <a href="altcliente.php?codcliente=<?= $cliente['codcliente'] ?>">Editar</a>
                        <a href="exccliente.php?codcliente=<?= $cliente['codcliente'] ?>">Excluir</a>
                    </td>
                </tr>
            <?php
                endforeach;
            } catch (PDOException $e) {
                $mensagem = "Erro ao listar os clientes: " . $e->getMessage();
            }
            ?>
        </tbody>
    </table>
</section>


</body>
</html>
