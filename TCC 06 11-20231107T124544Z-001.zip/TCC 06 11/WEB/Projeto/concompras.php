<?php
session_start();
include("conexao.php");

if ($conn) {
    $sql = "SELECT * FROM tb_compras";
    $stmc = $conn->prepare($sql);
    $stmc->execute();
    $resultado = $stmc->fetchAll(PDO::FETCH_ASSOC);

    if ($resultado) {
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/cabecalho_site.css">
    <link rel="stylesheet" href="../css/footer.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.js"></script>
    <script src="js/jquery.js"></script>
</head>
<body>
    <main>
        <table class="table table-striped table-bordered">
            <tr>
                <th>Código da Compra</th>
                <th>Data de Compra</th>
                <th>Data de Retirada</th>
                <th>Tipo de Pagamento</th>
                <th>Código do Cliente</th>
                <th>Ações</th>
            </tr>

            <?php foreach ($resultado as $compra) { ?>
                <tr>
                    <td><?php echo $compra['codcompra']; ?></td>
                    <td><?php echo $compra['datacompra']; ?></td>
                    <td><?php echo $compra['dataretirada']; ?></td>
                    <td><?php echo $compra['tipopagamento']; ?></td>
                    <td><?php echo $compra['idtb_clientes']; ?></td>
                    <td>
                        <a href="altcompra.php?codcompra=<?php echo $compra['codcompra']?>" class="btn btn-danger">Alterar</a>
                        <a href="exccompra.php?codcompra=<?php echo $compra['codcompra']?>" class="btn btn-danger" onclick="return confirm('Tem certeza de que deseja excluir esta compra?')">Excluir</a>
                    </td>
                </tr>
            <?php } ?>
        </table>
    </main>
</body>
</html>
<?php
    }
}
?>
