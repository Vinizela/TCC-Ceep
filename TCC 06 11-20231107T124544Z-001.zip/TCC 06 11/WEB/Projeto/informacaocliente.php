<?php
session_start();

if (!isset($_SESSION['cliente_id'])) {
    // Se o cliente não está logado, redirecione para a página de login
    header("Location: login.php");
    exit();
}

require_once('conexao.php'); // Inclua o arquivo de conexão

$cliente_id = $_SESSION['cliente_id'];

try {
    $sql = "SELECT * FROM tb_clientes WHERE codcliente = :cliente_id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':cliente_id', $cliente_id);
    $stmt->execute();
    $cliente = $stmt->fetch();

    if ($cliente) {
        // Agora você pode acessar os dados do cliente
        $nome = $cliente['nome'];
        $numero = $cliente['numero'];
        $email = $cliente['email'];
        $datanascimento = $cliente['datanascimento'];
        $cpf = $cliente['cpf'];
        $senha = $cliente['senha'];
        $idtb_cidades = $cliente['idtb_cidades'];

        try {
            // Consulta para obter a cidade do cliente
            $sql_cidade = "SELECT nomecidade, estado FROM tb_cidades WHERE codcidade = :idtb_cidades";
            $stmt_cidade = $conn->prepare($sql_cidade);
            $stmt_cidade->bindParam(':idtb_cidades', $idtb_cidades);
            $stmt_cidade->execute();
            $cidade = $stmt_cidade->fetch();

            if ($cidade) {
                $nome_cidade = $cidade['nomecidade'];
                $estado_cidade = $cidade['estado'];
            } else {
                echo "Cidade não encontrada.";
            }
        } catch (PDOException $e) {
            echo "Erro na consulta da cidade: " . $e->getMessage();
        }
    } else {
        echo "Cliente não encontrado.";
    }
} catch (PDOException $e) {
    echo "Erro na consulta: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OZZY</title>
    <link rel="shortcut icon" href="Projeto/img/favicon.ico"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php
    if ($cliente) {
    ?>
        <section class="cliente-conteudo" style="margin-top: 20px;">
            <div class="info-container">
                <div class="info">
                    <h3>Informações Pessoais</h3>
                    <p>Nome: <?php echo $nome; ?></p>
                    <p>Numero: <?php echo $numero; ?></p>
                    <p>Email: <?php echo $email; ?></p>
                    <p>Data de Nascimento: <?php echo $datanascimento; ?></p>
                    <p>CPF: <?php echo $cpf; ?></p>
                    <p>Senha: <?php echo $senha; ?></p>
                    <p>Cidade: <?php echo $nome_cidade; ?></p>
                    <p>Estado: <?php echo $estado_cidade; ?></p>
                </div>
                <div class="icons">
                    <a href="index.php" class="fas fa-sign-out-alt"> Sair da Conta</a>
                </div>
            </div>
        </section>
    <?php
    }
    ?>
</body>
</html>
