<?php
session_start();
include_once "conexao.php";

$pdo = new PDO("mysql:host=$hostname;dbname=$database_name", $username, $password);

$cod = isset($_GET['codcompra']) ? $_GET['codcompra'] : null; // Puxa o código da compra da URL

if ($cod !== null) {
    $sql = "SELECT * FROM tb_compras WHERE codcompra = :codcompra";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':codcompra', $cod);
    $stmt->execute();
    $compra = $stmt->fetch(PDO::FETCH_ASSOC);
}

if (isset($_POST['bt_atualizar'])) {
    $dataretirada = $_POST["dataretirada"];
    $datacompra = $_POST["datacompra"];
    $tipopagamento = $_POST["tipopagamento"];
    $idtb_clientes = $_POST["idtb_clientes"];

    $sql = "UPDATE tb_compras SET 
    dataretirada = :dataretirada,
    datacompra = :datacompra,
    tipopagamento = :tipopagamento,
    idtb_clientes = :idtb_clientes
    WHERE codcompra = :codcompra";

    $stmt = $pdo->prepare($sql);

    $stmt->bindParam(':codcompra', $cod);
    $stmt->bindParam(':dataretirada', $dataretirada);
    $stmt->bindParam(':datacompra', $datacompra);
    $stmt->bindParam(':tipopagamento', $tipopagamento);
    $stmt->bindParam(':idtb_clientes', $idtb_clientes);

    if ($stmt->execute()) {
        echo "Registro atualizado com sucesso";
        header("Location: paginaadm.php"); // Redirecione para a página de compras após a atualização
        exit();
    } else {
        echo "Não foi possível atualizar o registro";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alterar Compra</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <main class="formulario">
        <form action="" method="post">
            <p class="titulo_cadastro">Alterar Compra</p>
            <label for="codcompra">Código da Compra:</label>
            <input type="number" name="codcompra" value="<?php echo $compra['codcompra']; ?>" readonly>
            <label for="dataretirada">Data de Retirada:</label>
            <input type="date" name="dataretirada" value="<?php echo $compra['dataretirada']; ?>">
            <label for="datacompra">Data da Compra:</label>
            <input type="date" name="datacompra" value="<?php echo $compra['datacompra']; ?>">
            <label for="tipopagamento">Tipo de Pagamento:</label>
            <input type="text" name="tipopagamento" value="<?php echo $compra['tipopagamento']; ?>">
            <label for="idtb_clientes">ID do Cliente:</label>
            <input type="number" name="idtb_clientes" value="<?php echo $compra['idtb_clientes']; ?>">
            <input type="submit" name="bt_atualizar" value="Atualizar">
        </form>
    </main>
</body>
</html>
