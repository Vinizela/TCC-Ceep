<?php
session_start();

if (!isset($_SESSION['cliente_id'])) {
    // Se o cliente não está logado, redirecione para a página de login
    header("Location: login.php");
    exit();
}

require_once('conexao.php'); // Inclua o arquivo de conexão

$cliente_id = $_SESSION['cliente_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // O formulário foi submetido, atualize as informações do cliente
    $nome = $_POST['nome'];
    $numero = $_POST['numero'];
    $email = $_POST['email'];
    $datanascimento = $_POST['datanascimento'];
    $cpf = $_POST['cpf'];
    $idtb_cidades = $_POST['idtb_cidades'];

    try {
        $sql = "UPDATE tb_clientes SET nome = :nome, numero = :numero, email = :email, datanascimento = :datanascimento, cpf = :cpf, idtb_cidades = :idtb_cidades WHERE codcliente = :cliente_id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':nome', $nome);
        $stmt->bindParam(':numero', $numero);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':datanascimento', $datanascimento);
        $stmt->bindParam(':cpf', $cpf);
        $stmt->bindParam(':idtb_cidades', $idtb_cidades);
        $stmt->bindParam(':cliente_id', $cliente_id);
        $stmt->execute();

        // Redirecione de volta para a página de informações do cliente
        header("Location: informacaocliente.php");
        exit();
    } catch (PDOException $e) {
        echo "Erro na atualização das informações: " . $e->getMessage();
    }
}

// Consulte as informações do cliente no banco de dados
try {
    $sql = "SELECT * FROM tb_clientes WHERE codcliente = :cliente_id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':cliente_id', $cliente_id);
    $stmt->execute();
    $cliente = $stmt->fetch();

    if ($cliente) {
        // Agora você pode acessar os dados do cliente
        $nome = $cliente['nome'];
        $numero = $cliente['numero'];
        $email = $cliente['email'];
        $datanascimento = $cliente['datanascimento'];
        $cpf = $cliente['cpf'];
        $senha = $cliente['senha'];
        $idtb_cidades = $cliente['idtb_cidades'];
    } else {
        // Cliente não encontrado
        echo "Cliente não encontrado.";
    }
} catch (PDOException $e) {
    echo "Erro na consulta: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Informações do Cliente</title>
</head>
<body>
    <h1>Editar Informações do Cliente</h1>
    <form method="POST">
    <label for="idtb_cidades">Cidade:</label>
        <select name="idtb_cidades">
            <?php
                // Consulta as cidades no banco de dados
                $sql_cidades = "SELECT * FROM tb_cidades";
                $stmt_cidades = $conn->query($sql_cidades);
                $cidades = $stmt_cidades->fetchAll();

                foreach ($cidades as $cidade) {
                    $selected = ($cidade['codcidade'] == $idtb_cidades) ? 'selected' : '';
                    echo "<option value='{$cidade['codcidade']}' $selected>{$cidade['nomecidade']}</option>";
                }
            ?>
        </select>
        <label for="nome">Nome:</label>
        <input type="text" name="nome" value="<?php echo $nome; ?>" required>

        <label for="nome">Numero:</label>
        <input type="number" name="numero" value="<?php echo $numero; ?>" required>

        <label for="email">Email:</label>
        <input type="email" name="email" value="<?php echo $email; ?>" required>

        <label for="datanascimento">Data de Nascimento:</label>
        <input type="date" name="datanascimento" value="<?php echo $datanascimento; ?>" required>

        <label for="cpf">CPF:</label>
        <input type="text" name="cpf" value="<?php echo $cpf; ?>" required>

        <label for="senha">Senha:</label>
        <input type="password" name="senha" value="<?php echo $senha; ?>" required>

        <input type="submit" value="Salvar Alterações">
    </form>
</body>
</html>
